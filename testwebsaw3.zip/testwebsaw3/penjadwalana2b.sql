-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Aug 06, 2023 at 08:47 AM
-- Server version: 10.4.27-MariaDB
-- PHP Version: 8.2.0

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `penjadwalana2b`
--

-- --------------------------------------------------------

--
-- Table structure for table `aset`
--

CREATE TABLE `aset` (
  `id_aset` varchar(50) NOT NULL,
  `nama_aset` varchar(50) NOT NULL,
  `unit` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `aset`
--

INSERT INTO `aset` (`id_aset`, `nama_aset`, `unit`) VALUES
('0001', 'OSHKOSH STRIKER 1', 'ARFF'),
('0002', 'KANGLIM', 'PK'),
('0003', 'ZIEGLER', 'PK'),
('0004', 'SIMON GLOSTER SARO', 'PK'),
('0005', 'AMBULANCE 1', 'ARFF'),
('0006', 'AMBULANCE 2', 'ARFF'),
('0007', 'COMMANDO CAR', 'ARFF'),
('0008', 'FOAM TRUCK 1', 'PK'),
('0009', 'FOAM TRUCK 2', 'PK'),
('0010', 'UTILITY CAR 1', 'ARFF'),
('0011', 'UTILITY CAR 2', 'ARFF'),
('0012', 'FIRE TRUCK 1', 'PK'),
('0013', 'FIRE TRUCK 2', 'PK'),
('0014', 'PATROL CAR 1', 'ARFF'),
('0015', 'PATROL CAR 2', 'ARFF'),
('0016', 'RUNWAY SWEEPER 1', 'CLEANING'),
('0017', 'RUNWAY SWEEPER 2', 'CLEANING'),
('0018', 'RUBBER DEPOSIT REMOVER 1', 'CLEANING'),
('0019', 'RUBBER DEPOSIT REMOVER 2', 'CLEANING'),
('0020', 'RUNWAY FRICTION TESTER', 'CLEANING'),
('0021', 'JOHN DEERE 2 WD', 'TRACTOR'),
('0022', 'JOHN DEERE 4 WD', 'TRACTOR'),
('0023', 'MAHINDRA', 'TRACTOR'),
('0024', 'GP TRACTOR', 'TRACTOR'),
('0025', 'TUGAS AKHIR', 'PK');

-- --------------------------------------------------------

--
-- Table structure for table `bobot`
--

CREATE TABLE `bobot` (
  `frekuensi` tinyint(4) NOT NULL,
  `kondisi` tinyint(4) NOT NULL,
  `usia` tinyint(4) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `bobot`
--

INSERT INTO `bobot` (`frekuensi`, `kondisi`, `usia`) VALUES
(50, 30, 20);

-- --------------------------------------------------------

--
-- Table structure for table `penjadwalan`
--

CREATE TABLE `penjadwalan` (
  `id_jadwal` int(50) NOT NULL,
  `tgl_jadwal` date NOT NULL,
  `id_aset` varchar(50) NOT NULL,
  `unit` varchar(50) NOT NULL,
  `frekuensi` int(11) NOT NULL,
  `kondisi` int(11) NOT NULL,
  `usia` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `penjadwalan`
--

INSERT INTO `penjadwalan` (`id_jadwal`, `tgl_jadwal`, `id_aset`, `unit`, `frekuensi`, `kondisi`, `usia`) VALUES
(1, '2023-07-10', '0001', 'PK', 4, 1, 2),
(2, '2023-06-10', '0002', 'PK', 4, 2, 3),
(3, '2023-06-10', '0003', 'PK', 2, 1, 3),
(5, '2023-06-10', '0004', 'PK', 2, 3, 1),
(6, '2023-07-20', '0005', 'ARFF', 3, 2, 1),
(7, '2023-07-20', '0006', 'ARFF', 1, 3, 1),
(13, '2023-07-20', '0007', 'ARFF', 3, 1, 3),
(14, '2023-07-20', '0008', 'PK', 2, 2, 2),
(15, '2023-08-10', '0009', 'PK', 2, 1, 4),
(16, '2023-08-10', '0010', 'ARFF', 3, 2, 2),
(17, '2023-08-10', '0011', 'ARFF', 2, 1, 4),
(18, '2023-08-10', '0012', 'PK', 2, 3, 2),
(19, '2023-08-20', '0013', 'PK', 1, 1, 2),
(20, '2023-08-20', '0014', 'ARFF', 4, 3, 1),
(21, '2023-08-20', '0015', 'ARFF', 4, 2, 3),
(22, '2023-08-20', '0016', 'CLEANING', 4, 2, 3),
(23, '2024-07-15', '0017', 'CLEANING', 4, 2, 2),
(24, '2024-07-15', '0018', 'CLEANING', 3, 2, 1),
(25, '2024-07-15', '0019', 'CLEANING', 1, 2, 4),
(26, '2024-07-15', '0020', 'CLEANING', 3, 2, 3),
(27, '2024-08-15', '0021', 'TRACTOR', 3, 1, 1),
(28, '2024-08-15', '0022', 'TRACTOR', 3, 2, 3),
(29, '2024-08-15', '0023', 'TRACTOR', 2, 3, 3),
(30, '2024-08-15', '0024', 'TRACTOR', 2, 1, 3),
(31, '2023-08-03', '0025', 'PK', 3, 2, 4);

-- --------------------------------------------------------

--
-- Table structure for table `perangkingan`
--

CREATE TABLE `perangkingan` (
  `id_perangkingan` int(50) NOT NULL,
  `id_jadwal` int(50) NOT NULL,
  `tgl_jadwal` date NOT NULL,
  `n_frekuensi` varchar(50) NOT NULL,
  `n_kondisi` varchar(50) NOT NULL,
  `n_usia` varchar(50) NOT NULL,
  `preferensi` varchar(50) NOT NULL,
  `pj` varchar(50) NOT NULL,
  `teknisi` varchar(50) NOT NULL,
  `tgl_maintenance` varchar(10) NOT NULL,
  `status` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `perangkingan`
--

INSERT INTO `perangkingan` (`id_perangkingan`, `id_jadwal`, `tgl_jadwal`, `n_frekuensi`, `n_kondisi`, `n_usia`, `preferensi`, `pj`, `teknisi`, `tgl_maintenance`, `status`) VALUES
(1593, 1, '2023-07-10', '1', '0.33333333333333', '0.5', '0.7', '', '', '', ''),
(1594, 2, '2023-06-10', '1', '0.66666666666667', '0.33333333333333', '0.76666666666667', '', '', '', ''),
(1595, 3, '2023-06-10', '0.5', '0.33333333333333', '0.33333333333333', '0.41666666666667', '', '', '', ''),
(1596, 5, '2023-06-10', '0.5', '1', '1', '0.75', '', '', '', ''),
(1597, 6, '2023-07-20', '0.75', '0.66666666666667', '1', '0.775', '', '', '', ''),
(1598, 7, '2023-07-20', '0.25', '1', '1', '0.625', '', '', '', ''),
(1599, 13, '2023-07-20', '0.75', '0.33333333333333', '0.33333333333333', '0.54166666666667', '', '', '', ''),
(1600, 14, '2023-07-20', '0.5', '0.66666666666667', '0.5', '0.55', '', '', '', ''),
(1601, 15, '2023-08-10', '0.5', '0.33333333333333', '0.25', '0.4', '', '', '', ''),
(1602, 16, '2023-08-10', '0.75', '0.66666666666667', '0.5', '0.675', '', '', '', ''),
(1603, 17, '2023-08-10', '0.5', '0.33333333333333', '0.25', '0.4', '', '', '', ''),
(1604, 18, '2023-08-10', '0.5', '1', '0.5', '0.65', '', '', '', ''),
(1605, 19, '2023-08-20', '0.25', '0.33333333333333', '0.5', '0.325', '', '', '', ''),
(1606, 20, '2023-08-20', '1', '1', '1', '1', '', '', '', ''),
(1607, 21, '2023-08-20', '1', '0.66666666666667', '0.33333333333333', '0.76666666666667', '', '', '', ''),
(1608, 22, '2023-08-20', '1', '0.66666666666667', '0.33333333333333', '0.76666666666667', '', '', '', ''),
(1609, 23, '2024-07-15', '1', '0.66666666666667', '0.5', '0.8', '', '', '', ''),
(1610, 24, '2024-07-15', '0.75', '0.66666666666667', '1', '0.775', '', '', '', ''),
(1611, 25, '2024-07-15', '0.25', '0.66666666666667', '0.25', '0.375', '', '', '', ''),
(1612, 26, '2024-07-15', '0.75', '0.66666666666667', '0.33333333333333', '0.64166666666667', '', '', '', ''),
(1613, 27, '2024-08-15', '0.75', '0.33333333333333', '1', '0.675', '', '', '', ''),
(1614, 28, '2024-08-15', '0.75', '0.66666666666667', '0.33333333333333', '0.64166666666667', '', '', '', ''),
(1615, 29, '2024-08-15', '0.5', '1', '0.33333333333333', '0.61666666666667', '', '', '', ''),
(1616, 30, '2024-08-15', '0.5', '0.33333333333333', '0.33333333333333', '0.41666666666667', '', '', '', ''),
(1617, 31, '2023-08-03', '0.75', '0.66666666666667', '0.25', '0.625', '', '', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `id_user` int(15) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  `alamat` varchar(150) NOT NULL,
  `telepon` varchar(50) NOT NULL,
  `level` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id_user`, `username`, `password`, `alamat`, `telepon`, `level`) VALUES
(2, 'almira_ulima', 'd41d8cd98f00b204e9800998ecf8427e', 'Jl. Satu Perum Caladium Residence', '081209092002', 'Manager'),
(3, 'widya_prahasto', '827ccb0eea8a706c4c34a16891f84e7b', 'Jl. Indrakila No. 123', '081212345678', 'Senior Teknisi'),
(4, 'iwan_kurniawan', '827ccb0eea8a706c4c34a16891f84e7b', 'Gg. Mangga No. 123', '081287654321', 'Teknisi'),
(5, 'james_bond', '827ccb0eea8a706c4c34a16891f84e7b', 'Jl. MT Haryono Dalam No. 123', '081234345656', 'Staff Teknisi');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `aset`
--
ALTER TABLE `aset`
  ADD PRIMARY KEY (`id_aset`);

--
-- Indexes for table `penjadwalan`
--
ALTER TABLE `penjadwalan`
  ADD PRIMARY KEY (`id_jadwal`),
  ADD KEY `id_aset` (`id_aset`),
  ADD KEY `unit` (`unit`);

--
-- Indexes for table `perangkingan`
--
ALTER TABLE `perangkingan`
  ADD PRIMARY KEY (`id_perangkingan`),
  ADD KEY `id_jadwal` (`id_jadwal`),
  ADD KEY `tgl_jadwal` (`tgl_jadwal`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id_user`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `penjadwalan`
--
ALTER TABLE `penjadwalan`
  MODIFY `id_jadwal` int(50) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=32;

--
-- AUTO_INCREMENT for table `perangkingan`
--
ALTER TABLE `perangkingan`
  MODIFY `id_perangkingan` int(50) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1618;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `id_user` int(15) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `penjadwalan`
--
ALTER TABLE `penjadwalan`
  ADD CONSTRAINT `penjadwalan_ibfk_1` FOREIGN KEY (`id_aset`) REFERENCES `aset` (`id_aset`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `perangkingan`
--
ALTER TABLE `perangkingan`
  ADD CONSTRAINT `perangkingan_ibfk_1` FOREIGN KEY (`id_jadwal`) REFERENCES `penjadwalan` (`id_jadwal`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
